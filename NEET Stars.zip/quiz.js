const questions = [
  {
    question: "What is the unit of force?",
    options: ["Newton", "Joule", "Pascal", "Watt"],
    correct: 0
  },
  {
    question: "What is the acceleration due to gravity on Earth?",
    options: ["9.8 m/s²", "10 m/s²", "5 m/s²", "15 m/s²"],
    correct: 0
  },
  {
    question: "Who discovered gravity?",
    options: ["Newton", "Einstein", "Galileo", "Kepler"],
    correct: 0
  }
];

let currentQuestion = 0;
let score = 0;
let timer = 30;
let interval;
let attempted = 0;
let skipped = 0;
let incorrect = 0;

function startQuiz() {
  loadQuestion();
  interval = setInterval(updateTimer, 1000);
}

function loadQuestion() {
  const questionData = questions[currentQuestion];
  document.getElementById("question").textContent = questionData.question;
  const optionsContainer = document.getElementById("options-container");
  optionsContainer.innerHTML = "";

  questionData.options.forEach((option, index) => {
    const button = document.createElement("button");
    button.textContent = option;
    button.onclick = () => selectOption(index);
    optionsContainer.appendChild(button);
  });
}

function selectOption(selected) {
  const questionData = questions[currentQuestion];
  const optionsContainer = document.getElementById("options-container");
  const buttons = optionsContainer.querySelectorAll("button");

  buttons.forEach((button, index) => {
    if (index === questionData.correct) {
      button.classList.add("correct");
    } else if (index === selected) {
      button.classList.add("wrong");
    }
    button.disabled = true;
  });

  if (selected === questionData.correct) {
    score += 4;
    attempted++;
  } else {
    score -= 1;
    incorrect++;
  }
}

function updateTimer() {
  timer--;
  document.getElementById("time-left").textContent = timer;
  if (timer === 0) {
    nextQuestion();
  }
}

function nextQuestion() {
  if (currentQuestion < questions.length - 1) {
    currentQuestion++;
    timer = 30;
    loadQuestion();
  } else {
    endQuiz();
  }
}

function prevQuestion() {
  if (currentQuestion > 0) {
    currentQuestion--;
    timer = 30;
    loadQuestion();
  }
}

function endQuiz() {
  clearInterval(interval);
  document.getElementById("quiz-box").classList.add("hidden");
  document.getElementById("result-container").classList.remove("hidden");
  document.getElementById("score").textContent = `Your Score: ${score}`;
  document.getElementById("attempted").textContent = attempted;
  document.getElementById("skipped").textContent = skipped;
  document.getElementById("incorrect").textContent = incorrect;
}

function restartQuiz() {
  currentQuestion = 0;
  score = 0;
  timer = 30;
  attempted = 0;
  skipped = 0;
  incorrect = 0;
  document.getElementById("quiz-box").classList.remove("hidden");
  document.getElementById("result-container").classList.add("hidden");
  loadQuestion();
  interval = setInterval(updateTimer, 1000);
}

window.onload = startQuiz;

function viewSolutions() {
  // Redirect to solutions page
  window.location.href = "solution.html";
}


function saveQuizAttempt(chapterName, score) {
  // Get existing attempts from local storage
  let attempts = JSON.parse(localStorage.getItem('quizAttempts')) || [];
  
  // Add new attempt
  attempts.push({
    chapter: chapterName,
    score: score,
    date: new Date().toLocaleString()
  });
  
  // Save back to local storage
  localStorage.setItem('quizAttempts', JSON.stringify(attempts));
}

function endQuiz() {
  clearInterval(interval);

  // Save the quiz attempt (update this chapter name dynamically)
  saveQuizAttempt("Physics - Motion", score);

  // Show the result
  document.getElementById("quiz-box").classList.add("hidden");
  document.getElementById("result-container").classList.remove("hidden");
  document.getElementById("score").textContent = `Your Score: ${score}`;
  document.getElementById("attempted").textContent = attempted;
  document.getElementById("skipped").textContent = skipped;
  document.getElementById("incorrect").textContent = incorrect;
}