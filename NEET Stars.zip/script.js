function navigateTo(page) {
  // Page redirection logic
  window.location.href = page;
}

